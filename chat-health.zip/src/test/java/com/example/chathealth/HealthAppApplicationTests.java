package com.example.chathealth;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class HealthAppApplicationTests {

	@Test
	void contextLoads() {
	}

}
