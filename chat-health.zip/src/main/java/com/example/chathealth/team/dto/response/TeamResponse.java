package com.example.chathealth.team.dto.response;

public class TeamResponse {
}
