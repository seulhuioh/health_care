package com.example.chathealth.team.domain;

public class DeleteTeamRequest {
    private String teamName;

    public DeleteTeamRequest() {
    }


}
