package com.example.chathealth.team.dto.response;

public class TeamDeleteResponse {
    private String TeamName;
    public String getTeamName() {
        return TeamName;
    }
}
