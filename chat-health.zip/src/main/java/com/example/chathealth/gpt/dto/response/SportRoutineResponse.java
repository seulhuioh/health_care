package com.example.chathealth.gpt.dto.response;

public class SportRoutineResponse {
}
