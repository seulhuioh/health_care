package com.example.chathealth.history.dto;

public class DeleteContRequest {


}
